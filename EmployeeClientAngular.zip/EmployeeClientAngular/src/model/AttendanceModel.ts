import { Employee } from './Employee';

export class AttendanceModel{
    number: number;
    date: Date;
    status: number;
    empId : number;
} 