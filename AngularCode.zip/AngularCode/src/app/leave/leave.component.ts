import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { EmployeeService } from '../employee.service';
import { AttendanceModel } from 'src/model/AttendanceModel';

@Component({
  selector: 'app-leave',
  templateUrl: './leave.component.html',
  styleUrls: ['./leave.component.css']
})
export class LeaveComponent implements OnInit {
  id: any;
  demo: any;
  attendance: AttendanceModel;
  constructor(private router: Router, private service:EmployeeService) {
this.attendance = new AttendanceModel();
   }

  ngOnInit() {
  }
  applyLeave(attendance :AttendanceModel){
 
  this.id = sessionStorage.getItem('id');
  console.log(this.id);
  this.service.applyLeave1(this.attendance).subscribe(res=>{
    console.log("abcd");
    this.demo= res;
    console.log(this.demo);
   alert("You have applied leave for following date:"+[[Date]]);
  })

}


}


// viewLop() {
//   this.id = sessionStorage.getItem('id');
//   console.log(this.id);
//   this.service.viewLop(this.id).subscribe(res => {
//     console.log("abcd");
//     this.employee.id =this.id;
//     this.employee.lop = res;
//     //this.demo = res as number;
//     console.log(this.employee.lop);

//   })
// }