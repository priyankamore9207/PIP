import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CreateEmployeeComponent } from './create-employee/create-employee.component';
import { EmployeeListComponent } from './employee-list/employee-list.component';
import { EmployeeeDetailsComponent } from './employeee-details/employeee-details.component';
import { UpdateEmployeeComponent } from './update-employee/update-employee.component';
import { HttpClientModule } from '@angular/common/http';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { AdminComponent } from './admin/admin.component';
import { AdminStaffComponent } from './admin-staff/admin-staff.component';
import { EmployeeComponent } from './employee/employee.component';
import { EmployeeloginComponent } from './employeelogin/employeelogin.component';
import { AttendanceComponent } from './attendance/attendance.component';
import { LopComponent } from './lop/lop.component';
import { LeaveComponent } from './leave/leave.component';

@NgModule({
  declarations: [
    AppComponent,
    CreateEmployeeComponent,
    EmployeeListComponent,
    EmployeeeDetailsComponent,
    UpdateEmployeeComponent,
    HomeComponent,
    LoginComponent,
    AdminComponent,
    AdminStaffComponent,
    EmployeeComponent,
    EmployeeloginComponent,
    AttendanceComponent,
    LopComponent,
    LeaveComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
    
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
