import { Component, OnInit } from '@angular/core';
import { LoginModel } from 'src/model/LoginModel';
import { Router } from '@angular/router';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginCheck: LoginModel[];
  login: LoginModel;
  adminCheck: LoginModel;
  userName: any;
  password: any;
  constructor(private router: Router, private service: EmployeeService) { 
    this.login = new LoginModel();
this.userName= this.userName;
this.password = this.login.password;  
}

  ngOnInit() {
  }


  getAdmin(){
    this.service.getAdmin().subscribe(res=>{
      this.loginCheck= res;
      var success=false;
      this.loginCheck.forEach(element => {
        var admin = element;
        if(admin.userName === this.login.userName && admin.password === this.login.password){
          success=true;
        }
      });
      if(success){
        alert("Login success");
        this.router.navigate(['/admin'])
      }else{
        alert("Invalid Details")
      }

})
}


getAdmin1(){{
  console.log("pass")
  this.service.getAdmin().subscribe(res=>{
    this.loginCheck= res;
    this.adminCheck = this.loginCheck[0];
    // console.log(this.login.userName)
    // console.log(this.login.password)
    // console.log(this.adminCheck.userName)
    // console.log(this.adminCheck.password)

if(this.login.userName === this.adminCheck.userName && this.login.password === this.adminCheck.password){
// console.log(this.login.userName)
// console.log(this.login.password)
// console.log(this.adminCheck.userName)
// console.log(this.adminCheck.password)
this.router.navigate(['/admin'])
}
else{
alert("Invalid Details")
}

  })
}
}
}






// import { Component, OnInit } from '@angular/core';
// import { LoginModel } from '../model/LoginModel';
// import { Router } from '@angular/router';
// import { LoginserviceService } from '../loginservice.service';
// // import { VirtualTimeScheduler } from 'rxjs';
// // import { element } from 'protractor';

// @Component({
//   selector: 'app-login',
//   templateUrl: './login.component.html',
//   styleUrls: ['./login.component.css']
// })
// export class LoginComponent implements OnInit {
  // loginCheck: LoginModel[];
  // login: LoginModel;
  // adminCheck: LoginModel;
  // userName: any;
  // password: any;

//   constructor(private router: Router, private service: LoginserviceService){
// this.login = new LoginModel();
// this.userName= this.userName;
// this.password = this.login.password;
//   }
//   ngOnInit() {
//   }
// //   getAdmin(){
// //     console.log("pass")
// //     this.service.getAdmin().subscribe(res=>{
// //       this.loginCheck=res;
// //       this.adminCheck=this.loginCheck[0];
// //       console.log("Enter Details")
// //     console.log("re")
// //   this.router.navigate(['/admin'])
// // })
// //   }
//   getAdmin1(){{
//     console.log("pass")
//     this.service.getAdmin().subscribe(res=>{
//       this.loginCheck= res;
//       this.adminCheck = this.loginCheck[0];
//       // console.log(this.login.userName)
//       // console.log(this.login.password)
//       // console.log(this.adminCheck.userName)
//       // console.log(this.adminCheck.password)

// if(this.login.userName === this.adminCheck.userName && this.login.password === this.adminCheck.password){
//   // console.log(this.login.userName)
//   // console.log(this.login.password)
//   // console.log(this.adminCheck.userName)
//   // console.log(this.adminCheck.password)
//   this.router.navigate(['/admin'])
// }
// else{
//   alert("Invalid Details")
// }

//     })
//   }
//   }

//   getAdmin(){
//     this.service.getAdmin().subscribe(res=>{
//       this.loginCheck= res;
//       var success=false;
//       this.loginCheck.forEach(element => {
//         var admin = element;
//         if(admin.userName === this.login.userName && admin.password === this.login.password){
//           success=true;
//         }
//       });
//       if(success){
//         alert("Login success");
//         this.router.navigate(['/admin'])
//       }else{
//         alert("Invalid Details")
//       }

// })
// }
// }
