import { Injectable } from '@angular/core';
//import { HttpClient } from 'selenium-webdriver/http';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Employee } from 'src/model/Employee';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
  private baseUrl = 'http://localhost:8080';
  constructor(private http: HttpClient) { }

  getEmployeesList(): Observable<Employee[]> {
    return this.http.get<Employee[]>(this.baseUrl + '/getall');
  }

  getEmployee(id: number){
    return this.http.get(this.baseUrl + '/getById'+{id});
  }

  createEmployee(employee: Employee){
    return this.http.post<Employee>(this.baseUrl + '/add', employee);
  }

//   addEmployee(employee: Employee) {
//     return this.http.post<Employee>(this.baseUrl + '/addEmployee', employee);
// }

  // addPatient(patient: Patient) {
  //   return this.http.post<Patient>(this.baseUrl + '/addPatient', patient);
  // }

  // updateEmployee(id: number, value: any): Observable<Object> {
  //   return this.http.put(this.baseUrl + '/update' + {id}, value);
  // }

  updateEmployee(id: number,employee: Employee): Observable<Object> {
    return this.http.put(`${this.baseUrl}/update/${id}`, employee);
  }

  // deleteEmployee(id: number): Observable<any> {
  //   return this.http.delete(`${this.baseUrl}/${id}`, { responseType: 'text' });
  // }

  deleteEmployee(id: number){
    return this.http.delete(`${this.baseUrl}/delete/${id}`, {responseType:'text'});
  }

//   getEmployeesList(): Observable<any> {
//     return this.http.get<>
// }



}