import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { EmployeeService } from '../employee.service';
import { AttendanceModel } from 'src/model/AttendanceModel';

@Component({
  selector: 'app-leave',
  templateUrl: './leave.component.html',
  styleUrls: ['./leave.component.css']
})
export class LeaveComponent implements OnInit {
  id: any;
  date:any;
  submitted = false;
  attendance: AttendanceModel;
  constructor(private router: Router, private service:EmployeeService) {
   
this.attendance = new AttendanceModel();
this.date=this.attendance.date;
   }

  ngOnInit() {
  }
  applyLeave(){
 
  this.id = sessionStorage.getItem('id');
   this.attendance.empId=this.id;
   this.attendance.date=this.date;
   console.log(this.attendance);
  console.log(this.id);
  this.service.applyLeave(this.id,this.date).subscribe(res=>{
    console.log(res.toString);
   alert("You have applied leave on: "+String(this.date));
   this.router.navigate(['/attendance']);
   
  }
  )
}


}

