import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { Employee } from 'src/model/Employee';
import { EmployeeService } from '../employee.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css']
})



export class EmployeeListComponent implements OnInit {
  employees: Observable<Employee[]>;
 config: any;
  collection = { count: 60, employees: [] };
  Employee = [];
  pageOfItems: Array<Employee>;
  startIndex=0;
  endIndex=5;
  employee: Employee;
  employeeArr: Employee[] = [];
    
  constructor(private employeeService: EmployeeService,
    private router: Router) {
      //  for (var i = 0; i < this.collection.count; i++) {
      //   this.collection.employees.push(
          // {
          //   id: i + 1,
          //   value: "items number " + (i + 1)
          // }
      //   );
      // }
      // this.config = {
      //   itemsPerPage: 1,
      //   currentPage: 1,
      //   totalItems: this.collection.count
      // };
     }

  ngOnInit() {
    this.reloadData();
   // this.items = Array(20).fill(0).map((x, i) => ({ id: (i + 1), name: `Item ${i + 1}`}));
   // this.items = Array(Employee).fill(Employee).map((x, i)=>({ id: (i + 1), name: `Employee ${i + 1}` }))
  }


   
  // pageChanged(event){
  //   this.config.currentPage = event;
  // }
  // pageChanged(pageOfItems: Array<Employee>) {
  //     // update current page of items
  //     this.pageOfItems = pageOfItems;
  // }

  getEmployee() {
    this.employees = this.employeeService.getEmployeesList();
   
  }

  reloadData() {

    this.employeeService.getEmployeesList().subscribe(res => {

      this.employeeArr = res;
      JSON.stringify(this.employeeArr);

    });
  }


  updateIndex(pageIndex){
    console.log(pageIndex)
    this.startIndex = pageIndex * 5;
    this.endIndex = this.startIndex + 5;
  }

  previousIndex(pageIndex){
    this.startIndex = this.startIndex-5;
    this.endIndex = this.startIndex + 5;
  }

  nextIndex(pageIndex){
    this.startIndex = this.startIndex+5;
    this.endIndex = this.startIndex + 5;
  }

  deleteEmployee(id: number) {
    this.employeeService.deleteEmployee(id)
      .subscribe(
        data => {
          console.log(data);
          this.reloadData();
          alert("Deleted Successfully.")
        },
        error => console.log(error));
  }

  employeeDetails(id: number){
    this.router.navigate(['details', id]);
  }

  updateEmployee(id: number,employee: Employee){
    this.router.navigate(['update',id,employee]);
  }
  

}







// import { Component, OnInit, NgZone } from '@angular/core';
// import { Employee } from '../model/employeeDetails';
// import { LoginServiceService } from '../login-service.service';
// import { Router } from '@angular/router';
// import { ChangeDetectorRef } from '@angular/core';
// import { filter } from 'rxjs/operators';
// import {Sort} from '@angular/material/sort';
// import { MatSort, MatSortable, MatTableDataSource,MatPaginator } from '@angular/material';
// @Component({
//   selector: 'app-admin',
//   templateUrl: './admin.component.html',
//   styleUrls: ['./admin.component.css']
// })
// export class AdminComponent implements OnInit {

//   employeeArr: Employee[] = [];
//   employee: Employee;
//   sortedSet: Employee[];
//   startIndex=0;
//   endIndex=5;
//   constructor(private router: Router, private service: LoginServiceService, private ref: ChangeDetectorRef, private zone: NgZone) {
//     this.getEmployee();
//     this.sortedSet= this.employeeArr.slice();

//   }

//   ngOnInit() {
//     //  this.getEmployee();

//   }

//   sortData(sort: Sort) {
//     console.log("working")
//     const data = this.employeeArr.slice();
//     if (!sort.active || sort.direction === '') {
//       this.sortedSet = data;
//       return;
//     }

//     this.sortedSet = data.sort((a, b) => {
//       const isAsc = sort.direction === 'asc';
//       switch (sort.active) {

//         case 'id': return compare(a.id, b.id, isAsc);
//         case 'firstName': return compare(a.firstName, b.firstName, isAsc);
//         case 'lastName': return compare(a.lastName, b.lastName, isAsc);
//         case 'employeeGender': return compare(a.employeeGender, b.employeeGender, isAsc);
//         case 'employeeEmailId': return compare(a.employeeEmailId, b.employeeEmailId, isAsc);
//         case 'employeeContact': return compare(a.employeeContact, b.employeeContact, isAsc);
//         case 'employeeDesignation': return compare(a.employeeDesignation, b.employeeDesignation, isAsc);
//         case 'salary': return compare(a.salary, b.salary, isAsc);
//         default: return 0;
//       }

//     });
//     console.log("working1");
//     this.getEmployee();
//     console.log("working2")
//   }

//   updateIndex(pageIndex){
//     console.log(pageIndex)
//     this.startIndex = pageIndex * 5;
//     this.endIndex = this.startIndex + 5;
//   }

//   previousIndex(pageIndex){
//     this.startIndex = this.startIndex-5;
//     this.endIndex = this.startIndex + 5;
//   }

//   nextIndex(pageIndex){
//     this.startIndex = this.startIndex+5;
//     this.endIndex = this.startIndex + 5;
//   }

//   getEmployee() {

//     this.service.getEmployee().subscribe(res => {

//       this.employeeArr = res;
//       JSON.stringify(this.employeeArr);

//     });
//   }

//   deleteConfirm(id: number) {
//     if (confirm("Are you sure you want to delete Employee with ID: " + id)) {
//       console.log("Implement delete functionality");
//       this.deleteEmployee(id);
//     }
//   }

//   deleteEmployee(id: number): void {
//     this.service.deleteEmployee(id)
//       .subscribe(data => {
//         console.log(data);
//         JSON.stringify(data);
//         //alert('Employee details deleted successfully.')
//       },
//         error => {
//           console.log(error);
//         },
//         () => {
//           console.log('get employee');
//           this.getEmployee();
//         });
//   }


// }
// function compare(a: number | string, b: number | string, isAsc: boolean) {
//   console.log("compare")
//   return (a < b ? -1 : 1) * (isAsc ? 1 : -1);
// }