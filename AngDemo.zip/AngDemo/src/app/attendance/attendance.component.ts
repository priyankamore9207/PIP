import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { EmployeeService } from '../employee.service';
import { AttendanceModel } from 'src/model/AttendanceModel';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-attendance',
  templateUrl: './attendance.component.html',
  styleUrls: ['./attendance.component.css']
})
export class AttendanceComponent implements OnInit {
//attendance: AttendanceModel;
//attendances: Observable<AttendanceModel[]>;
demo:any;
// empId: any;
// date: any;
// status: any;
id:any;

  constructor(private route: ActivatedRoute,private router: Router, private service: EmployeeService) {
   }

  ngOnInit() {
    this.getEmployeeAttendance();
  }

  getEmployeeAttendance(){
    this.id=sessionStorage.getItem('id');
    console.log(this.id);
    //console.log("abcd");
    this.service.getEmployeeAttendance(this.id).subscribe(res=>
      {
        //  console.log("abcd");
        //alert("Attendance dispayed")
        // console.log(res);
       this.demo = res;
       console.log(this.demo);
      });

  }
      
}


